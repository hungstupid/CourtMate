# T05 PA3 supporting sources

The editable submission document is `T05-PA3.docx`, supplied beside the PDF. This archive supplies its diagram and screen assets.

- `diagrams/architecture`: four submitted PNG figures and matching editable draw.io diagrams.
- `diagrams/object-data`: eighteen submitted PNG figures and editable semantic draw.io reconstructions retained from the object/data handoff. The reconstructions preserve the design model; their layout is not the exact export origin of the PNGs. Use the PNGs/document for the submitted figure appearance.
- `diagrams/screen-flows`: six PNG and draw.io pairs generated from the same coordinates, labels and edges.
- `screens`: all 58 primary PA2 frame exports. Dates are fixed prototype scenarios, not live availability.
- `screen-manifest.csv`: primary-screen IDs, use cases and exact editable Figma links. `all-pa2-frame-targets.json` also preserves supporting targets.
- `traceability.csv`: the 49-row functional RTM from Section 7.
- `adr`: three architecture decisions, with status preserved as Proposed pending team review.

PA3 is a design baseline. Pending runtime/accessibility/concurrency checks are explicitly distinguished from inspected design evidence. This package does not claim application test execution or Moodle submission.
