# CourtMate PA1 — organized LaTeX source

This is a **structural-only** split of the original `main.tex`. All original LaTeX content has been preserved verbatim across the included `.tex` files; the document text, tables, diagram definitions, links, and formatting commands have not been edited.

## Structure

- `main.tex`: entry point, document class and `\input{...}` calls.
- `config/`: packages, colors, document typography/table rules, headings, header/footer.
- `figures/`: TikZ definitions for the C4 context diagram and Gantt chart.
- `frontmatter/`: cover, table of contents, objectives.
- `sections/`: Sections 1–7; longer sections are split again by subsection.
- `logo.png`: original image asset (unchanged).

## Compile

On Overleaf, upload all contents and select `main.tex` as the main document. Use the **same compiler as the original project** (pdfLaTeX, XeLaTeX, or LuaLaTeX, depending on the fonts available in your environment).

For a local LaTeX setup:

```bash
latexmk -pdf -interaction=nonstopmode main.tex
# or, with installed matching fonts:
latexmk -xelatex -interaction=nonstopmode main.tex
```

Keep the folder structure intact: `\input{...}` paths are relative to the root `main.tex`. This split does not alter PA1 content or resolve any pre-existing content issues.
